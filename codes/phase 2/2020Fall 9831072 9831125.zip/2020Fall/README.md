# CE202-LC-Lab-Material 

## Logic Fianl Project (Fall, 2020 Semester)

### Smart Home System
This is final project of 2020, Fall Semester. 

### Description

### Grading Table
